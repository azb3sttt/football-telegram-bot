# Nazwy używane do wybrania popularnych lig z jednego wywołania /leagues?current=true.
# Dopasowanie bierze też kraj, aby ograniczyć kolizje nazw.
POPULAR_LEAGUES: list[tuple[str, str | None]] = [
    ("Premier League", "England"),
    ("La Liga", "Spain"),
    ("Serie A", "Italy"),
    ("Bundesliga", "Germany"),
    ("Ligue 1", "France"),
    ("Ekstraklasa", "Poland"),
    ("UEFA Champions League", None),
    ("UEFA Europa League", None),
    ("UEFA Conference League", None),
    ("Eredivisie", "Netherlands"),
    ("Primeira Liga", "Portugal"),
    ("Süper Lig", "Turkey"),
    ("Jupiler Pro League", "Belgium"),
    ("Premiership", "Scotland"),
    ("Championship", "England"),
    ("Major League Soccer", "USA"),
    ("Serie A", "Brazil"),
    ("Liga Profesional Argentina", "Argentina"),
    ("Saudi Pro League", "Saudi-Arabia"),
    ("Liga MX", "Mexico"),
]
