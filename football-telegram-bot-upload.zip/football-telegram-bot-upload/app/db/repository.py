from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime

from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker
from sqlalchemy.orm import selectinload

from app.db.models import Coupon, FixtureSnapshot, NotificationSettings, Selection, User


class Repository:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def ensure_user(self, user_id: int, username: str | None = None, unit_size: float = 1.0) -> User:
        async with self.session_factory() as session:
            user = await session.get(User, user_id)
            if user is None:
                user = User(id=user_id, username=username, unit_size=unit_size)
                session.add(user)
                session.add(NotificationSettings(user_id=user_id))
            elif username != user.username:
                user.username = username
            await session.commit()
            return user

    async def get_notification_settings(self, user_id: int) -> NotificationSettings:
        async with self.session_factory() as session:
            settings = await session.get(NotificationSettings, user_id)
            if settings is None:
                session.add(User(id=user_id))
                settings = NotificationSettings(user_id=user_id)
                session.add(settings)
                await session.commit()
            return settings

    async def toggle_notification(self, user_id: int, field: str) -> NotificationSettings:
        allowed = {"selection_result", "coupon_result", "daily_report", "weekly_report", "monthly_report"}
        if field not in allowed:
            raise ValueError("Nieobsługiwane ustawienie powiadomień")
        async with self.session_factory() as session:
            row = await session.get(NotificationSettings, user_id)
            if row is None:
                row = NotificationSettings(user_id=user_id)
                session.add(row)
            setattr(row, field, not getattr(row, field))
            await session.commit()
            await session.refresh(row)
            return row

    async def upsert_fixture(self, payload: dict) -> FixtureSnapshot:
        async with self.session_factory() as session:
            fixture_id = int(payload["fixture"]["id"])
            row = await session.get(FixtureSnapshot, fixture_id)
            if row is None:
                row = FixtureSnapshot(
                    fixture_id=fixture_id,
                    home_team=payload["teams"]["home"]["name"],
                    away_team=payload["teams"]["away"]["name"],
                )
                session.add(row)
            fixture = payload.get("fixture", {})
            league = payload.get("league", {})
            teams = payload.get("teams", {})
            goals = payload.get("goals", {})
            row.league_id = league.get("id")
            row.league_name = league.get("name")
            row.home_team_id = teams.get("home", {}).get("id")
            row.away_team_id = teams.get("away", {}).get("id")
            row.home_team = teams.get("home", {}).get("name") or row.home_team
            row.away_team = teams.get("away", {}).get("name") or row.away_team
            date = fixture.get("date")
            row.kickoff = datetime.fromisoformat(date) if date else row.kickoff
            row.status = fixture.get("status", {}).get("short") or row.status
            row.home_goals = goals.get("home")
            row.away_goals = goals.get("away")
            row.updated_at = datetime.now().astimezone()
            await session.commit()
            return row

    async def create_coupon(self, user_id: int, picks: list[dict], target_odds: float | None = None) -> Coupon:
        if not picks:
            raise ValueError("Kupon musi zawierać co najmniej jeden typ")
        total_odds = 1.0
        for pick in picks:
            total_odds *= float(pick["odds"])
        async with self.session_factory() as session:
            coupon = Coupon(user_id=user_id, target_odds=target_odds, total_odds=round(total_odds, 4))
            session.add(coupon)
            await session.flush()
            for pick in picks:
                session.add(
                    Selection(
                        coupon_id=coupon.id,
                        user_id=user_id,
                        fixture_id=int(pick["fixture_id"]),
                        league_id=pick.get("league_id"),
                        league_name=pick.get("league_name"),
                        home_team=pick["home_team"],
                        away_team=pick["away_team"],
                        kickoff=pick.get("kickoff"),
                        market=pick["market"],
                        selection=pick["selection"],
                        line=pick.get("line"),
                        odds=float(pick["odds"]),
                        model_probability=pick.get("model_probability"),
                        confidence=pick.get("confidence"),
                        edge=pick.get("edge"),
                    )
                )
            await session.commit()
            query = (
                select(Coupon)
                .options(selectinload(Coupon.selections))
                .where(Coupon.id == coupon.id)
            )
            return (await session.execute(query)).scalar_one()

    async def get_coupon(self, coupon_id: int) -> Coupon | None:
        async with self.session_factory() as session:
            query = select(Coupon).options(selectinload(Coupon.selections)).where(Coupon.id == coupon_id)
            return (await session.execute(query)).scalar_one_or_none()

    async def pending_fixture_ids(self) -> list[int]:
        async with self.session_factory() as session:
            query = select(Selection.fixture_id).where(Selection.status == "pending").distinct()
            return list((await session.scalars(query)).all())

    async def pending_selections_for_fixture(self, fixture_id: int) -> list[Selection]:
        async with self.session_factory() as session:
            query = select(Selection).where(
                Selection.fixture_id == fixture_id,
                Selection.status == "pending",
            )
            return list((await session.scalars(query)).all())

    async def settle_selection(
        self,
        selection_id: int,
        status: str,
        final_result: str,
        profit_loss: float,
    ) -> Selection:
        async with self.session_factory() as session:
            row = await session.get(Selection, selection_id)
            if row is None:
                raise LookupError("Nie znaleziono typu")
            row.status = status
            row.final_result = final_result
            row.profit_loss = round(float(profit_loss), 4)
            row.settled_at = datetime.now().astimezone()
            await session.commit()
            await session.refresh(row)
            return row

    async def recalculate_coupon(self, coupon_id: int) -> Coupon:
        async with self.session_factory() as session:
            query = select(Coupon).options(selectinload(Coupon.selections)).where(Coupon.id == coupon_id)
            coupon = (await session.execute(query)).scalar_one()
            statuses = [s.status for s in coupon.selections]
            if any(status == "pending" for status in statuses):
                coupon.status = "pending"
                coupon.profit_loss = None
            elif any(status == "lost" for status in statuses):
                coupon.status = "lost"
                coupon.profit_loss = -coupon.stake_units
            else:
                effective_odds = 1.0
                for s in coupon.selections:
                    if s.status == "won":
                        # Dla Asian Handicap ćwiartkowego dokładny P/L selekcji może być częściowy.
                        # W AKO traktujemy taki wybór konserwatywnie: mnożnik z P/L jednostkowego.
                        effective_odds *= max(1.0 + float(s.profit_loss or 0.0), 0.0)
                    elif s.status in {"push", "void"}:
                        effective_odds *= 1.0
                coupon.profit_loss = round(coupon.stake_units * (effective_odds - 1.0), 4)
                coupon.status = "won" if coupon.profit_loss > 0 else "push"
            await session.commit()
            return coupon

    async def selections_between(
        self,
        start: datetime,
        end: datetime,
        user_id: int | None = None,
        settled_only: bool = True,
    ) -> list[Selection]:
        async with self.session_factory() as session:
            clauses = [Selection.created_at >= start, Selection.created_at < end]
            if user_id is not None:
                clauses.append(Selection.user_id == user_id)
            if settled_only:
                clauses.append(Selection.status.in_(["won", "lost", "push", "void"]))
            query = select(Selection).where(and_(*clauses)).order_by(Selection.created_at.asc())
            return list((await session.scalars(query)).all())

    async def latest_settled(self, user_id: int, limit: int = 10) -> list[Selection]:
        async with self.session_factory() as session:
            query = (
                select(Selection)
                .where(Selection.user_id == user_id, Selection.status.in_(["won", "lost", "push", "void"]))
                .order_by(Selection.settled_at.desc())
                .limit(limit)
            )
            return list((await session.scalars(query)).all())

    async def all_user_ids(self) -> list[int]:
        async with self.session_factory() as session:
            return list((await session.scalars(select(User.id))).all())

    async def notification_user_ids(self, field: str) -> list[int]:
        if field not in {"daily_report", "weekly_report", "monthly_report"}:
            return []
        async with self.session_factory() as session:
            query = select(NotificationSettings.user_id).where(getattr(NotificationSettings, field).is_(True))
            return list((await session.scalars(query)).all())

    async def fixture_count_for_day(self, start: datetime, end: datetime) -> int:
        async with self.session_factory() as session:
            query = select(func.count()).select_from(FixtureSnapshot).where(
                FixtureSnapshot.kickoff >= start,
                FixtureSnapshot.kickoff < end,
            )
            return int((await session.scalar(query)) or 0)

    async def analyzed_count_for_day(self, start: datetime, end: datetime) -> int:
        async with self.session_factory() as session:
            query = select(func.count(func.distinct(Selection.fixture_id))).where(
                Selection.created_at >= start,
                Selection.created_at < end,
            )
            return int((await session.scalar(query)) or 0)

    async def get_user_unit(self, user_id: int) -> float:
        async with self.session_factory() as session:
            user = await session.get(User, user_id)
            return float(user.unit_size if user else 1.0)

    async def set_user_unit(self, user_id: int, unit_size: float) -> None:
        async with self.session_factory() as session:
            user = await session.get(User, user_id)
            if user is None:
                user = User(id=user_id, unit_size=unit_size)
                session.add(user)
                session.add(NotificationSettings(user_id=user_id))
            else:
                user.unit_size = unit_size
            await session.commit()
