from __future__ import annotations

from dataclasses import dataclass
from typing import Any

FINISHED_STATUSES = {"FT", "AET", "PEN"}
VOID_STATUSES = {"CANC", "ABD", "AWD", "WO"}
WAIT_STATUSES = {"NS", "TBD", "PST", "SUSP", "INT", "1H", "HT", "2H", "ET", "BT", "P"}


@dataclass(slots=True)
class Settlement:
    status: str  # won/lost/push/void/pending
    profit_loss: float
    final_result: str


def _num(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace("%", "")
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def statistics_by_side(fixture: dict, raw_stats: list[dict]) -> dict[str, dict[str, float]]:
    home_id = fixture.get("teams", {}).get("home", {}).get("id")
    away_id = fixture.get("teams", {}).get("away", {}).get("id")
    result: dict[str, dict[str, float]] = {"home": {}, "away": {}}
    for row in raw_stats:
        team_id = row.get("team", {}).get("id")
        side = "home" if team_id == home_id else "away" if team_id == away_id else None
        if side is None:
            continue
        for item in row.get("statistics", []):
            value = _num(item.get("value"))
            if value is not None:
                result[side][str(item.get("type", ""))] = value
    return result


def _fulltime_score(fixture: dict) -> tuple[int | None, int | None]:
    score = fixture.get("score", {}).get("fulltime", {})
    home = score.get("home")
    away = score.get("away")
    # Dla zwykłego FT część dostawców może nie wypełnić score.fulltime — wtedy używamy goals.
    if home is None or away is None:
        goals = fixture.get("goals", {})
        home = goals.get("home")
        away = goals.get("away")
    return home, away


def _simple_line_settlement(value: float, line: float, direction: str, odds: float, label: str) -> Settlement:
    direction = direction.lower()
    if abs(value - line) < 1e-9:
        return Settlement("push", 0.0, f"{label}: {value:g} przy linii {line:g} — zwrot")
    won = value > line if direction == "over" else value < line
    if won:
        return Settlement("won", odds - 1.0, f"{label}: {value:g}, linia {direction.upper()} {line:g}")
    return Settlement("lost", -1.0, f"{label}: {value:g}, linia {direction.upper()} {line:g}")


def _normalize_selection(text: str) -> str:
    return text.strip().lower().replace(" ", "_").replace("-", "_")


def _asian_components(line: float) -> list[float]:
    # Linie ćwiartkowe dzielimy na dwa zakłady po 0.5 stawki.
    quarter = round(line * 4)
    normalized = quarter / 4
    if abs(normalized - line) > 1e-6:
        return [line]
    frac = abs(quarter) % 4
    if frac in {1, 3}:
        lower = (quarter - 1) / 4
        upper = (quarter + 1) / 4
        return [lower, upper]
    return [normalized]


def _asian_handicap(diff: float, line: float, odds: float) -> Settlement:
    components = _asian_components(line)
    stake_part = 1.0 / len(components)
    profit = 0.0
    outcomes: list[str] = []
    for component in components:
        adjusted = diff + component
        if adjusted > 1e-9:
            profit += stake_part * (odds - 1.0)
            outcomes.append("wygrana")
        elif adjusted < -1e-9:
            profit -= stake_part
            outcomes.append("przegrana")
        else:
            outcomes.append("zwrot")
    if profit > 1e-9:
        status = "won"
    elif profit < -1e-9:
        status = "lost"
    else:
        status = "push"
    detail = "/".join(outcomes)
    return Settlement(status, round(profit, 6), f"Asian handicap {line:+g}: {detail}")


def settle_selection(selection: Any, fixture: dict, raw_stats: list[dict] | None = None) -> Settlement:
    status_short = fixture.get("fixture", {}).get("status", {}).get("short", "NS")
    if status_short in VOID_STATUSES:
        return Settlement("void", 0.0, f"Mecz ma status {status_short} — zakład anulowany")
    if status_short not in FINISHED_STATUSES:
        return Settlement("pending", 0.0, f"Mecz jeszcze nie jest rozliczony ({status_short})")

    home_goals, away_goals = _fulltime_score(fixture)
    if home_goals is None or away_goals is None:
        return Settlement("pending", 0.0, "Brak końcowego wyniku w API")

    market = _normalize_selection(str(selection.market))
    pick = _normalize_selection(str(selection.selection))
    line = selection.line
    odds = float(selection.odds)
    home_goals_f = float(home_goals)
    away_goals_f = float(away_goals)

    if market in {"1x2", "match_winner"}:
        if home_goals > away_goals:
            actual = "home"
        elif home_goals < away_goals:
            actual = "away"
        else:
            actual = "draw"
        aliases = {"1": "home", "x": "draw", "2": "away", "gospodarze": "home", "remis": "draw", "goscie": "away", "goście": "away"}
        wanted = aliases.get(pick, pick)
        won = wanted == actual
        text = f"Wynik 90 min: {home_goals}:{away_goals}; typ: {wanted}"
        return Settlement("won" if won else "lost", odds - 1.0 if won else -1.0, text)

    if market in {"double_chance", "podwojna_szansa", "podwójna_szansa"}:
        actuals = {"1x": home_goals >= away_goals, "x2": away_goals >= home_goals, "12": home_goals != away_goals}
        won = actuals.get(pick, False)
        return Settlement("won" if won else "lost", odds - 1.0 if won else -1.0, f"Wynik 90 min: {home_goals}:{away_goals}; typ {pick.upper()}")

    if market in {"btts", "both_teams_to_score"}:
        actual_yes = home_goals > 0 and away_goals > 0
        wanted_yes = pick in {"yes", "tak", "btts_yes"}
        won = actual_yes == wanted_yes
        return Settlement("won" if won else "lost", odds - 1.0 if won else -1.0, f"Gole: {home_goals}:{away_goals}; BTTS {'TAK' if actual_yes else 'NIE'}")

    if market in {"total_goals", "goals", "over_under"}:
        if line is None:
            return Settlement("void", 0.0, "Brak linii dla rynku goli")
        direction = "over" if "over" in pick or "powyzej" in pick or "powyżej" in pick else "under"
        return _simple_line_settlement(home_goals_f + away_goals_f, float(line), direction, odds, "Łączna liczba goli")

    if market in {"team_goals", "gole_druzyny", "gole_drużyny"}:
        if line is None:
            return Settlement("void", 0.0, "Brak linii dla goli drużyny")
        side = "home" if pick.startswith("home") or pick.startswith("gospodar") else "away"
        direction = "over" if "over" in pick or "powy" in pick else "under"
        value = home_goals_f if side == "home" else away_goals_f
        label = "Gole gospodarzy" if side == "home" else "Gole gości"
        return _simple_line_settlement(value, float(line), direction, odds, label)

    if market in {"asian_handicap", "handicap_azjatycki", "ah"}:
        if line is None:
            return Settlement("void", 0.0, "Brak linii Asian Handicap")
        side = "home" if pick in {"home", "gospodarze", "1"} or pick.startswith("home") else "away"
        diff = home_goals_f - away_goals_f if side == "home" else away_goals_f - home_goals_f
        result = _asian_handicap(diff, float(line), odds)
        result.final_result += f"; wynik 90 min {home_goals}:{away_goals}; strona {side}"
        return result

    stats = statistics_by_side(fixture, raw_stats or [])

    if market in {"corners_total", "total_corners", "rogi", "rzuty_rozne", "rzuty_rożne"}:
        if line is None:
            return Settlement("void", 0.0, "Brak linii rzutów rożnych")
        h = stats["home"].get("Corner Kicks")
        a = stats["away"].get("Corner Kicks")
        if h is None or a is None:
            return Settlement("pending", 0.0, "Brak końcowych statystyk rzutów rożnych")
        direction = "over" if "over" in pick or "powy" in pick else "under"
        return _simple_line_settlement(h + a, float(line), direction, odds, "Łączne rzuty rożne")

    if market in {"corners_team", "team_corners", "rogi_druzyny", "rogi_drużyny"}:
        if line is None:
            return Settlement("void", 0.0, "Brak linii rzutów rożnych drużyny")
        side = "home" if pick.startswith("home") or pick.startswith("gospodar") else "away"
        value = stats[side].get("Corner Kicks")
        if value is None:
            return Settlement("pending", 0.0, "Brak końcowych statystyk rzutów rożnych drużyny")
        direction = "over" if "over" in pick or "powy" in pick else "under"
        return _simple_line_settlement(value, float(line), direction, odds, f"Rożne {'gospodarzy' if side == 'home' else 'gości'}")

    if market in {"cards_total", "total_cards", "kartki"}:
        if line is None:
            return Settlement("void", 0.0, "Brak linii kartek")
        yellow_h = stats["home"].get("Yellow Cards")
        yellow_a = stats["away"].get("Yellow Cards")
        red_h = stats["home"].get("Red Cards", 0.0)
        red_a = stats["away"].get("Red Cards", 0.0)
        if yellow_h is None or yellow_a is None:
            return Settlement("pending", 0.0, "Brak końcowych statystyk kartek")
        value = yellow_h + yellow_a + red_h + red_a
        direction = "over" if "over" in pick or "powy" in pick else "under"
        return _simple_line_settlement(value, float(line), direction, odds, "Kartki (żółte + czerwone po 1)")

    if market in {"cards_team", "team_cards", "kartki_druzyny", "kartki_drużyny"}:
        if line is None:
            return Settlement("void", 0.0, "Brak linii kartek drużyny")
        side = "home" if pick.startswith("home") or pick.startswith("gospodar") else "away"
        yellow = stats[side].get("Yellow Cards")
        red = stats[side].get("Red Cards", 0.0)
        if yellow is None:
            return Settlement("pending", 0.0, "Brak końcowych statystyk kartek drużyny")
        direction = "over" if "over" in pick or "powy" in pick else "under"
        return _simple_line_settlement(yellow + red, float(line), direction, odds, f"Kartki {'gospodarzy' if side == 'home' else 'gości'}")

    return Settlement("void", 0.0, f"Nieobsługiwany rynek: {selection.market}")
