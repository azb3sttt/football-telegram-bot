from __future__ import annotations

import json
from pathlib import Path

from app.data.leagues import POPULAR_LEAGUES
from app.services.football_api import FootballApiClient


class LeagueCatalog:
    def __init__(self, api: FootballApiClient, path: str = "cache/leagues.json") -> None:
        self.api = api
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    async def sync(self) -> list[dict]:
        leagues = await self.api.current_leagues()
        selected: list[dict] = []
        for wanted_name, wanted_country in POPULAR_LEAGUES:
            for row in leagues:
                league = row.get("league", {})
                country = row.get("country", {})
                if league.get("name") != wanted_name:
                    continue
                if wanted_country and country.get("name") != wanted_country:
                    continue
                selected.append(
                    {
                        "id": league.get("id"),
                        "name": league.get("name"),
                        "country": country.get("name"),
                        "type": league.get("type"),
                        "seasons": row.get("seasons", []),
                    }
                )
                break
        self.path.write_text(json.dumps(selected, ensure_ascii=False, indent=2), encoding="utf-8")
        return selected

    def load(self) -> list[dict]:
        if not self.path.exists():
            return []
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            return []

    def ids(self) -> set[int]:
        return {int(row["id"]) for row in self.load() if row.get("id") is not None}
