from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from statistics import mean
from typing import Iterable
from zoneinfo import ZoneInfo

from app.db.models import Selection
from app.db.repository import Repository


@dataclass(slots=True)
class Metrics:
    count: int
    won: int
    lost: int
    push: int
    void: int
    total_staked: float
    returned: float
    profit: float
    yield_pct: float
    roi_pct: float
    hit_rate: float
    avg_odds: float
    avg_confidence: float


def calculate_metrics(rows: Iterable[Selection]) -> Metrics:
    data = list(rows)
    won = sum(r.status == "won" for r in data)
    lost = sum(r.status == "lost" for r in data)
    push = sum(r.status == "push" for r in data)
    void = sum(r.status == "void" for r in data)
    performance_rows = [r for r in data if r.status in {"won", "lost", "push"}]
    total_staked = float(len(performance_rows))
    profit = sum(float(r.profit_loss or 0.0) for r in performance_rows)
    returned = total_staked + profit
    yield_pct = (profit / total_staked * 100.0) if total_staked else 0.0
    decided = won + lost
    hit_rate = (won / decided * 100.0) if decided else 0.0
    avg_odds = mean([float(r.odds) for r in performance_rows]) if performance_rows else 0.0
    confs = [float(r.confidence) for r in performance_rows if r.confidence is not None]
    avg_confidence = mean(confs) if confs else 0.0
    return Metrics(
        count=len(data),
        won=won,
        lost=lost,
        push=push,
        void=void,
        total_staked=total_staked,
        returned=returned,
        profit=profit,
        yield_pct=yield_pct,
        roi_pct=yield_pct,
        hit_rate=hit_rate,
        avg_odds=avg_odds,
        avg_confidence=avg_confidence,
    )


def group_metrics(rows: list[Selection], key) -> list[tuple[str, Metrics]]:
    groups: dict[str, list[Selection]] = defaultdict(list)
    for row in rows:
        groups[str(key(row))].append(row)
    result = [(name, calculate_metrics(items)) for name, items in groups.items()]
    result.sort(key=lambda x: (x[1].yield_pct, x[1].count), reverse=True)
    return result


def confidence_bucket(row: Selection) -> str:
    if row.confidence is None:
        return "brak"
    low = max(0, (row.confidence // 10) * 10)
    return f"{low}–{low + 9}%"


def odds_bucket(row: Selection) -> str:
    o = float(row.odds)
    if o < 1.50:
        return "<1.50"
    if o < 1.80:
        return "1.50–1.79"
    if o < 2.20:
        return "1.80–2.19"
    if o < 3.00:
        return "2.20–2.99"
    return "3.00+"


def calibration(rows: list[Selection]) -> list[tuple[str, int, int, float]]:
    groups: dict[str, list[Selection]] = defaultdict(list)
    for row in rows:
        if row.confidence is not None and row.status in {"won", "lost"}:
            groups[confidence_bucket(row)].append(row)
    output = []
    for bucket, items in sorted(groups.items()):
        won = sum(x.status == "won" for x in items)
        real = won / len(items) * 100 if items else 0.0
        output.append((bucket, len(items), won, real))
    return output


class ReportService:
    def __init__(self, repo: Repository, timezone: str = "Europe/Warsaw") -> None:
        self.repo = repo
        self.tz = ZoneInfo(timezone)

    def _now(self) -> datetime:
        return datetime.now(self.tz)

    async def range_rows(self, user_id: int, start: datetime, end: datetime) -> list[Selection]:
        return await self.repo.selections_between(start, end, user_id=user_id, settled_only=True)

    async def daily(self, user_id: int, day: datetime | None = None) -> tuple[datetime, datetime, list[Selection]]:
        now = day or self._now()
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
        return start, end, await self.range_rows(user_id, start, end)

    async def last_days(self, user_id: int, days: int) -> tuple[datetime, datetime, list[Selection]]:
        end = self._now()
        start = end - timedelta(days=days)
        return start, end, await self.range_rows(user_id, start, end)

    async def month(self, user_id: int, reference: datetime | None = None, previous: bool = False) -> tuple[datetime, datetime, list[Selection]]:
        now = reference or self._now()
        current_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        if previous:
            end = current_start
            previous_day = current_start - timedelta(days=1)
            start = previous_day.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        else:
            start = current_start
            if start.month == 12:
                end = start.replace(year=start.year + 1, month=1)
            else:
                end = start.replace(month=start.month + 1)
        return start, end, await self.range_rows(user_id, start, end)


def _fmt_signed(value: float) -> str:
    return f"{value:+.2f}"


def format_metrics_report(title: str, start: datetime, end: datetime, rows: list[Selection]) -> str:
    m = calculate_metrics(rows)
    market_groups = group_metrics(rows, lambda r: r.market) if rows else []
    best = market_groups[0] if market_groups else None
    worst = market_groups[-1] if market_groups else None
    lines = [
        title,
        "",
        f"Okres: {start:%d.%m.%Y} – {(end - timedelta(seconds=1)):%d.%m.%Y}",
        "",
        f"🎯 Typy: {m.count}",
        f"✅ Trafione: {m.won}",
        f"❌ Nietrafione: {m.lost}",
        f"↩️ Zwroty: {m.push}",
        f"🚫 Anulowane: {m.void}",
        f"Skuteczność: {m.hit_rate:.2f}%",
        "",
        f"💰 Suma stawek: {m.total_staked:.2f} units",
        f"💵 Zwrot: {m.returned:.2f} units",
        f"📈 Profit: {_fmt_signed(m.profit)} units",
        f"📊 Yield: {_fmt_signed(m.yield_pct)}%",
        f"📈 ROI: {_fmt_signed(m.roi_pct)}%",
        f"Średni kurs: {m.avg_odds:.2f}",
        f"Średni confidence: {m.avg_confidence:.0f}/100",
    ]
    if best:
        lines += ["", f"Najlepszy rynek: {best[0]} ({best[1].yield_pct:+.1f}%)"]
    if worst and worst != best:
        lines += [f"Najsłabszy rynek: {worst[0]} ({worst[1].yield_pct:+.1f}%)"]
    cal = calibration(rows)
    if cal:
        lines += ["", "🎯 Kalibracja modelu", "Confidence | Predykcje | Trafione | Real %"]
        for bucket, count, won, real in cal:
            lines.append(f"{bucket} | {count} | {won} | {real:.1f}%")
    return "\n".join(lines)


def format_yield_breakdown(rows: list[Selection]) -> str:
    if not rows:
        return "Brak zakończonych typów w wybranym okresie."
    sections = ["📊 YIELD — SZCZEGÓŁY"]
    dimensions = [
        ("RYNEK", lambda r: r.market),
        ("LIGA", lambda r: r.league_name or str(r.league_id or "brak")),
        ("KURS", odds_bucket),
        ("CONFIDENCE", confidence_bucket),
    ]
    for label, key in dimensions:
        sections += ["", f"— {label} —"]
        for name, metrics in group_metrics(rows, key)[:12]:
            sections.append(f"{name}: {metrics.count} typów | Yield {metrics.yield_pct:+.2f}% | P/L {metrics.profit:+.2f}u")
    return "\n".join(sections)
