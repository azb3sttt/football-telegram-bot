from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any


class DiskJsonCache:
    def __init__(self, directory: str = "cache") -> None:
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        digest = hashlib.sha256(key.encode("utf-8")).hexdigest()
        return self.directory / f"{digest}.json"

    def get(self, key: str, ttl_seconds: int) -> Any | None:
        path = self._path(key)
        if not path.exists():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if time.time() - float(payload["stored_at"]) > ttl_seconds:
                return None
            return payload["data"]
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def set(self, key: str, data: Any) -> None:
        path = self._path(key)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(
            json.dumps({"stored_at": time.time(), "data": data}, ensure_ascii=False),
            encoding="utf-8",
        )
        tmp.replace(path)
