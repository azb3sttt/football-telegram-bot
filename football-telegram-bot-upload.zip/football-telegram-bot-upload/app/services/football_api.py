from __future__ import annotations

import json
import logging
from datetime import date
from typing import Any

import httpx

from app.services.cache import DiskJsonCache

logger = logging.getLogger(__name__)


class FootballApiError(RuntimeError):
    pass


class FootballApiClient:
    def __init__(self, api_key: str, base_url: str, cache: DiskJsonCache | None = None) -> None:
        self.api_key = api_key.strip()
        self.base_url = base_url.rstrip("/")
        self.cache = cache or DiskJsonCache()
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"x-apisports-key": self.api_key, "Accept": "application/json"},
            timeout=httpx.Timeout(20.0),
        )
        self.last_remaining_requests: int | None = None

    async def close(self) -> None:
        await self.client.aclose()

    async def _get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        *,
        cache_ttl: int = 0,
    ) -> dict[str, Any]:
        if not self.api_key:
            raise FootballApiError("Brak FOOTBALL_API_KEY")
        clean_params = {k: v for k, v in (params or {}).items() if v is not None}
        cache_key = f"{path}?{json.dumps(clean_params, sort_keys=True, ensure_ascii=False)}"
        if cache_ttl > 0:
            cached = self.cache.get(cache_key, cache_ttl)
            if cached is not None:
                return cached
        try:
            response = await self.client.get(path, params=clean_params)
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise FootballApiError("Nie udało się pobrać danych z API piłkarskiego") from exc

        remaining = response.headers.get("x-ratelimit-requests-remaining")
        if remaining and remaining.isdigit():
            self.last_remaining_requests = int(remaining)

        data = response.json()
        errors = data.get("errors")
        if errors:
            raise FootballApiError(f"API zwróciło błąd: {errors}")
        if cache_ttl > 0:
            self.cache.set(cache_key, data)
        return data

    async def health_check(self) -> bool:
        try:
            await self._get("/status", cache_ttl=60)
            return True
        except FootballApiError:
            return False

    async def fixtures_by_date(self, day: date, timezone: str = "Europe/Warsaw") -> list[dict[str, Any]]:
        data = await self._get(
            "/fixtures",
            {"date": day.isoformat(), "timezone": timezone},
            cache_ttl=120,
        )
        return list(data.get("response", []))

    async def fixture(self, fixture_id: int, *, live_ttl: int = 45) -> dict[str, Any] | None:
        data = await self._get("/fixtures", {"id": fixture_id}, cache_ttl=live_ttl)
        rows = data.get("response", [])
        return rows[0] if rows else None

    async def fixtures_batch(self, fixture_ids: list[int], *, ttl: int = 45) -> list[dict[str, Any]]:
        if not fixture_ids:
            return []
        # API-Football obsługuje do 20 ID rozdzielonych myślnikiem.
        output: list[dict[str, Any]] = []
        for idx in range(0, len(fixture_ids), 20):
            batch = fixture_ids[idx : idx + 20]
            data = await self._get("/fixtures", {"ids": "-".join(map(str, batch))}, cache_ttl=ttl)
            output.extend(data.get("response", []))
        return output

    async def fixture_statistics(self, fixture_id: int, *, ttl: int = 120) -> list[dict[str, Any]]:
        data = await self._get("/fixtures/statistics", {"fixture": fixture_id}, cache_ttl=ttl)
        return list(data.get("response", []))

    async def fixture_events(self, fixture_id: int, *, ttl: int = 120) -> list[dict[str, Any]]:
        data = await self._get("/fixtures/events", {"fixture": fixture_id}, cache_ttl=ttl)
        return list(data.get("response", []))

    async def recent_team_fixtures(self, team_id: int, limit: int = 5) -> list[dict[str, Any]]:
        data = await self._get("/fixtures", {"team": team_id, "last": limit}, cache_ttl=900)
        return list(data.get("response", []))

    async def head_to_head(self, home_team_id: int, away_team_id: int, limit: int = 5) -> list[dict[str, Any]]:
        data = await self._get(
            "/fixtures/headtohead",
            {"h2h": f"{home_team_id}-{away_team_id}", "last": limit},
            cache_ttl=1800,
        )
        return list(data.get("response", []))

    async def current_leagues(self) -> list[dict[str, Any]]:
        data = await self._get("/leagues", {"current": "true"}, cache_ttl=86400)
        return list(data.get("response", []))

    async def odds_for_fixture(self, fixture_id: int) -> list[dict[str, Any]]:
        data = await self._get("/odds", {"fixture": fixture_id}, cache_ttl=300)
        return list(data.get("response", []))
