from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from app.services.football_api import FootballApiClient


@dataclass(slots=True)
class CandidatePick:
    fixture_id: int
    league_id: int | None
    league_name: str | None
    home_team: str
    away_team: str
    kickoff: datetime | None
    market: str
    selection: str
    line: float | None
    odds: float
    model_probability: float
    confidence: int
    edge: float
    explanation: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "fixture_id": self.fixture_id,
            "league_id": self.league_id,
            "league_name": self.league_name,
            "home_team": self.home_team,
            "away_team": self.away_team,
            "kickoff": self.kickoff,
            "market": self.market,
            "selection": self.selection,
            "line": self.line,
            "odds": self.odds,
            "model_probability": self.model_probability,
            "confidence": self.confidence,
            "edge": self.edge,
            "explanation": self.explanation,
        }


def _team_goals_from_fixture(row: dict, team_id: int) -> tuple[int, int] | None:
    home_id = row.get("teams", {}).get("home", {}).get("id")
    away_id = row.get("teams", {}).get("away", {}).get("id")
    gh = row.get("goals", {}).get("home")
    ga = row.get("goals", {}).get("away")
    if gh is None or ga is None:
        return None
    if team_id == home_id:
        return int(gh), int(ga)
    if team_id == away_id:
        return int(ga), int(gh)
    return None


def _averages(fixtures: list[dict], team_id: int) -> tuple[float, float, float, float]:
    rows = [x for row in fixtures if (x := _team_goals_from_fixture(row, team_id)) is not None]
    if not rows:
        return 1.2, 1.2, 0.5, 0.5
    scored = [x[0] for x in rows]
    conceded = [x[1] for x in rows]
    avg_for = sum(scored) / len(scored)
    avg_against = sum(conceded) / len(conceded)
    btts = sum(1 for gf, ga in rows if gf > 0 and ga > 0) / len(rows)
    over25 = sum(1 for gf, ga in rows if gf + ga > 2.5) / len(rows)
    return avg_for, avg_against, btts, over25


def _poisson_pmf(k: int, lam: float) -> float:
    return math.exp(-lam) * (lam**k) / math.factorial(k)


def _prob_total_over(lam_total: float, line: float) -> float:
    # Obsługa popularnych linii x.5. Dla całkowitych linii model zwraca prawdopodobieństwo wygranej,
    # a push jest osobnym zdarzeniem i nie jest sztucznie doliczany.
    threshold = math.floor(line)
    return 1.0 - sum(_poisson_pmf(k, lam_total) for k in range(threshold + 1))


def _prob_btts(lam_home: float, lam_away: float) -> float:
    return (1.0 - math.exp(-lam_home)) * (1.0 - math.exp(-lam_away))


def _prob_1x2(lam_home: float, lam_away: float) -> dict[str, float]:
    home = draw = away = 0.0
    for h in range(9):
        ph = _poisson_pmf(h, lam_home)
        for a in range(9):
            p = ph * _poisson_pmf(a, lam_away)
            if h > a:
                home += p
            elif h == a:
                draw += p
            else:
                away += p
    total = home + draw + away
    return {"home": home / total, "draw": draw / total, "away": away / total}


def _extract_odds(raw: list[dict]) -> dict[tuple[str, str, float | None], float]:
    output: dict[tuple[str, str, float | None], float] = {}
    if not raw:
        return output
    bookmakers = raw[0].get("bookmakers", [])
    if not bookmakers:
        return output

    # Bierzemy pierwszego dostępnego bukmachera z API; nazwa bukmachera nie wpływa na model.
    bets = bookmakers[0].get("bets", [])
    for bet in bets:
        name = str(bet.get("name", "")).lower()
        for value in bet.get("values", []):
            label = str(value.get("value", "")).strip()
            try:
                odd = float(value.get("odd"))
            except (TypeError, ValueError):
                continue
            low = label.lower()
            if name == "match winner":
                sel = {"home": "home", "draw": "draw", "away": "away"}.get(low)
                if sel:
                    output[("1x2", sel, None)] = odd
            elif "goals over/under" in name or name in {"goals over under", "goals over/under"}:
                parts = low.split()
                if len(parts) >= 2 and parts[0] in {"over", "under"}:
                    try:
                        line = float(parts[-1])
                    except ValueError:
                        continue
                    output[("total_goals", parts[0], line)] = odd
            elif name in {"both teams score", "both teams to score"}:
                if low in {"yes", "no"}:
                    output[("btts", low, None)] = odd
    return output


class MatchAnalyzer:
    def __init__(self, api: FootballApiClient) -> None:
        self.api = api

    async def analyze_fixture(self, fixture: dict) -> list[CandidatePick]:
        fixture_id = int(fixture["fixture"]["id"])
        home_id = int(fixture["teams"]["home"]["id"])
        away_id = int(fixture["teams"]["away"]["id"])
        home_name = fixture["teams"]["home"]["name"]
        away_name = fixture["teams"]["away"]["name"]
        league = fixture.get("league", {})
        kickoff_text = fixture.get("fixture", {}).get("date")
        kickoff = datetime.fromisoformat(kickoff_text) if kickoff_text else None

        home_recent = await self.api.recent_team_fixtures(home_id, 5)
        away_recent = await self.api.recent_team_fixtures(away_id, 5)
        odds_raw = await self.api.odds_for_fixture(fixture_id)
        market_odds = _extract_odds(odds_raw)

        h_for, h_against, h_btts, h_o25 = _averages(home_recent, home_id)
        a_for, a_against, a_btts, a_o25 = _averages(away_recent, away_id)
        lam_home = max(0.25, min(3.5, (h_for + a_against) / 2))
        lam_away = max(0.25, min(3.5, (a_for + h_against) / 2))
        lam_total = lam_home + lam_away

        probs: list[tuple[str, str, float | None, float, str]] = []
        for line in (1.5, 2.5, 3.5):
            p = _prob_total_over(lam_total, line)
            probs.append(
                (
                    "total_goals",
                    "over",
                    line,
                    p,
                    f"Model bramek: {lam_home:.2f} + {lam_away:.2f} = {lam_total:.2f}; "
                    f"w ostatnich 5 meczach wskaźnik over 2.5 wynosił {h_o25:.0%}/{a_o25:.0%}.",
                )
            )
        p_btts = _prob_btts(lam_home, lam_away)
        probs.append(
            (
                "btts",
                "yes",
                None,
                p_btts,
                f"BTTS w ostatnich 5: {home_name} {h_btts:.0%}, {away_name} {a_btts:.0%}; "
                f"model Poissona daje {p_btts:.1%}.",
            )
        )
        one_x_two = _prob_1x2(lam_home, lam_away)
        for sel in ("home", "draw", "away"):
            probs.append(
                (
                    "1x2",
                    sel,
                    None,
                    one_x_two[sel],
                    f"Średnie gole (5 ostatnich): {home_name} {h_for:.2f}/{h_against:.2f}, "
                    f"{away_name} {a_for:.2f}/{a_against:.2f}.",
                )
            )

        candidates: list[CandidatePick] = []
        for market, selection, line, probability, explanation in probs:
            odd = market_odds.get((market, selection, line))
            if not odd or odd <= 1.01:
                continue
            implied = 1.0 / odd
            edge = probability - implied
            confidence = int(round(probability * 100))
            # Nie prezentujemy losowych typów: wymagamy rozsądnego modelowego prawdopodobieństwa i dodatniego edge.
            if confidence < 55 or edge < 0.02:
                continue
            candidates.append(
                CandidatePick(
                    fixture_id=fixture_id,
                    league_id=league.get("id"),
                    league_name=league.get("name"),
                    home_team=home_name,
                    away_team=away_name,
                    kickoff=kickoff,
                    market=market,
                    selection=selection,
                    line=line,
                    odds=odd,
                    model_probability=round(probability, 4),
                    confidence=confidence,
                    edge=round(edge, 4),
                    explanation=explanation,
                )
            )
        candidates.sort(key=lambda x: (x.edge, x.confidence), reverse=True)
        return candidates

    async def best_today(
        self,
        fixtures: list[dict],
        popular_league_ids: set[int],
        *,
        max_fixtures: int = 8,
    ) -> list[CandidatePick]:
        eligible = [
            f
            for f in fixtures
            if f.get("fixture", {}).get("status", {}).get("short") in {"NS", "TBD"}
            and (not popular_league_ids or f.get("league", {}).get("id") in popular_league_ids)
        ]
        eligible.sort(key=lambda f: f.get("fixture", {}).get("timestamp") or 0)
        output: list[CandidatePick] = []
        for fixture in eligible[:max_fixtures]:
            try:
                output.extend((await self.analyze_fixture(fixture))[:2])
            except Exception:
                # Pojedynczy brak kursów/statystyk nie może wywrócić całego /top lub /kupon.
                continue
        output.sort(key=lambda x: (x.edge, x.confidence), reverse=True)
        return output

    @staticmethod
    def build_coupon(candidates: list[CandidatePick], target_odds: float) -> list[CandidatePick]:
        if target_odds <= 1:
            target_odds = 2.0
        # Jeden typ na mecz, aby kupon nie był sztucznie skorelowany.
        unique: list[CandidatePick] = []
        seen: set[int] = set()
        for pick in candidates:
            if pick.fixture_id in seen:
                continue
            seen.add(pick.fixture_id)
            unique.append(pick)

        selected: list[CandidatePick] = []
        combined = 1.0
        # Zachłannie zbliżamy się do celu, preferując wysokie edge.
        for pick in unique:
            if len(selected) >= 6:
                break
            if combined >= target_odds * 0.92:
                break
            selected.append(pick)
            combined *= pick.odds
        return selected
