from __future__ import annotations

from app.db.models import Coupon, Selection
from app.services.analysis import CandidatePick

STATUS_EMOJI = {
    "won": "✅ TRAFIONY",
    "lost": "❌ NIETRAFIONY",
    "push": "↩️ ZWROT",
    "pending": "⏳ OCZEKUJE",
    "void": "🚫 ANULOWANY",
}

MARKET_NAMES = {
    "1x2": "🎯 1X2",
    "total_goals": "⚽ Gole",
    "team_goals": "⚽ Gole drużyny",
    "btts": "⚽ BTTS",
    "corners_total": "🚩 Rzuty rożne",
    "corners_team": "🚩 Rożne drużyny",
    "cards_total": "🟨 Kartki",
    "cards_team": "🟨 Kartki drużyny",
    "asian_handicap": "📐 Asian Handicap",
}


def pick_label(market: str, selection: str, line: float | None) -> str:
    if market == "total_goals":
        return f"{'Over' if selection == 'over' else 'Under'} {line:g} gola"
    if market == "btts":
        return f"BTTS {'TAK' if selection == 'yes' else 'NIE'}"
    if market == "1x2":
        return {"home": "1 — gospodarze", "draw": "X — remis", "away": "2 — goście"}.get(selection, selection)
    if market == "asian_handicap":
        return f"{selection} {line:+g} AH"
    if line is not None:
        return f"{selection} {line:g}"
    return selection


def format_candidate(pick: CandidatePick, index: int | None = None) -> str:
    prefix = f"{index}️⃣ " if index and 1 <= index <= 9 else ""
    return (
        f"{prefix}{pick.home_team} – {pick.away_team}\n"
        f"{MARKET_NAMES.get(pick.market, pick.market)}: {pick_label(pick.market, pick.selection, pick.line)}\n"
        f"Kurs: {pick.odds:.2f}\n"
        f"Model: {pick.model_probability:.1%} | Confidence: {pick.confidence}/100 | Edge: {pick.edge:+.1%}\n"
        f"Dlaczego: {pick.explanation}"
    )


def format_selection_result(selection: Selection, fixture_score: str) -> str:
    return (
        f"✅ MECZ ZAKOŃCZONY\n\n"
        f"{selection.home_team} – {selection.away_team} {fixture_score}\n\n"
        f"Twój typ:\n{MARKET_NAMES.get(selection.market, selection.market)} "
        f"{pick_label(selection.market, selection.selection, selection.line)}\n\n"
        f"Wynik rozliczenia:\n{selection.final_result or '-'}\n\n"
        f"{STATUS_EMOJI.get(selection.status, selection.status)}\n"
        f"Kurs: {selection.odds:.2f}\n"
        f"P/L: {float(selection.profit_loss or 0):+.2f} units"
    )


def format_coupon_summary(coupon: Coupon) -> str:
    lines = ["🎟 PODSUMOWANIE KUPONU", ""]
    for idx, s in enumerate(coupon.selections, 1):
        lines += [
            f"{idx}. {s.home_team} – {s.away_team}",
            f"{pick_label(s.market, s.selection, s.line)}",
            STATUS_EMOJI.get(s.status, s.status),
            f"Kurs: {s.odds:.2f}",
            "",
        ]
    lines += [
        f"Łączny kurs: {coupon.total_odds:.2f}",
        f"Wynik kuponu: {STATUS_EMOJI.get(coupon.status, coupon.status)}",
    ]
    if coupon.profit_loss is not None:
        lines.append(f"P/L kuponu (1 unit): {coupon.profit_loss:+.2f} units")
    return "\n".join(lines)
