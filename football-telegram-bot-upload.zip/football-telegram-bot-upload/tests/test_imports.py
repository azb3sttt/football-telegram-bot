import importlib.util

import pytest


def test_core_imports():
    import app.services.analysis  # noqa: F401
    import app.services.football_api  # noqa: F401
    import app.services.reports  # noqa: F401
    import app.services.settlement  # noqa: F401


def test_telegram_imports_when_runtime_dependencies_exist():
    if importlib.util.find_spec("telegram") is None or importlib.util.find_spec("aiosqlite") is None:
        pytest.skip("Brak runtime dependencies w środowisku testowym")
    import app.bot  # noqa: F401
    import app.commands  # noqa: F401
    import app.scheduler  # noqa: F401
