from app.services.analysis import MatchAnalyzer, CandidatePick


def pick(fid, odds, edge):
    return CandidatePick(
        fixture_id=fid,
        league_id=39,
        league_name="Premier League",
        home_team=f"H{fid}",
        away_team=f"A{fid}",
        kickoff=None,
        market="total_goals",
        selection="over",
        line=1.5,
        odds=odds,
        model_probability=0.75,
        confidence=75,
        edge=edge,
        explanation="test",
    )


def test_coupon_uses_one_pick_per_fixture():
    rows = [pick(1, 1.5, 0.2), pick(1, 2.0, 0.1), pick(2, 1.6, 0.15), pick(3, 1.7, 0.12)]
    selected = MatchAnalyzer.build_coupon(rows, 3.5)
    assert len({x.fixture_id for x in selected}) == len(selected)
