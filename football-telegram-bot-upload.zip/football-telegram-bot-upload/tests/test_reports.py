from types import SimpleNamespace

import pytest

from app.services.reports import calculate_metrics, calibration


def row(status, odds, pl, confidence=70, market="total_goals", league_name="Premier League"):
    return SimpleNamespace(
        status=status,
        odds=odds,
        profit_loss=pl,
        confidence=confidence,
        market=market,
        league_name=league_name,
        league_id=39,
    )


def test_yield_math():
    rows = [row("won", 2.0, 1.0), row("lost", 1.8, -1.0), row("won", 1.5, 0.5)]
    metrics = calculate_metrics(rows)
    assert metrics.total_staked == 3
    assert metrics.profit == pytest.approx(0.5)
    assert metrics.yield_pct == pytest.approx(100 * 0.5 / 3)
    assert metrics.returned == pytest.approx(3.5)


def test_push_counts_stake_with_zero_profit_and_void_excluded():
    rows = [row("push", 2.0, 0.0), row("void", 2.0, 0.0)]
    metrics = calculate_metrics(rows)
    assert metrics.total_staked == 1
    assert metrics.profit == 0


def test_calibration():
    rows = [row("won", 1.8, 0.8, 74), row("lost", 1.8, -1, 76), row("won", 1.8, 0.8, 78)]
    data = calibration(rows)
    assert data[0][0] == "70–79%"
    assert data[0][1] == 3
    assert data[0][2] == 2
    assert data[0][3] == pytest.approx(66.666, rel=1e-2)
