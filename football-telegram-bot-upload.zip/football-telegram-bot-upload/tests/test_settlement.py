from dataclasses import dataclass

import pytest

from app.services.settlement import settle_selection


@dataclass
class Pick:
    market: str
    selection: str
    line: float | None
    odds: float


def fixture(home=2, away=1, status="FT"):
    return {
        "fixture": {"status": {"short": status}},
        "teams": {"home": {"id": 1}, "away": {"id": 2}},
        "goals": {"home": home, "away": away},
        "score": {"fulltime": {"home": home, "away": away}},
    }


def stats(corners=(7, 3), yellows=(2, 4), reds=(0, 1)):
    def row(team_id, c, y, r):
        return {
            "team": {"id": team_id},
            "statistics": [
                {"type": "Corner Kicks", "value": c},
                {"type": "Yellow Cards", "value": y},
                {"type": "Red Cards", "value": r},
            ],
        }
    return [row(1, corners[0], yellows[0], reds[0]), row(2, corners[1], yellows[1], reds[1])]


def test_1x2_home_win():
    result = settle_selection(Pick("1x2", "home", None, 1.8), fixture())
    assert result.status == "won"
    assert result.profit_loss == pytest.approx(0.8)


def test_btts_yes():
    result = settle_selection(Pick("btts", "yes", None, 1.7), fixture(2, 1))
    assert result.status == "won"


def test_goals_over():
    result = settle_selection(Pick("total_goals", "over", 2.5, 1.9), fixture(2, 1))
    assert result.status == "won"


def test_corners_are_settled_from_stats_not_score():
    result = settle_selection(Pick("corners_team", "home_over", 4.5, 1.55), fixture(0, 4), stats(corners=(7, 1)))
    assert result.status == "won"
    assert "7" in result.final_result


def test_cards_total():
    result = settle_selection(Pick("cards_total", "over", 6.5, 1.9), fixture(), stats(yellows=(2, 4), reds=(0, 1)))
    assert result.status == "won"


def test_asian_handicap_push():
    result = settle_selection(Pick("asian_handicap", "home", -1.0, 1.9), fixture(2, 1))
    assert result.status == "push"
    assert result.profit_loss == 0


def test_asian_handicap_half_loss_quarter_line():
    result = settle_selection(Pick("asian_handicap", "home", -0.25, 2.0), fixture(1, 1))
    assert result.status == "lost"
    assert result.profit_loss == pytest.approx(-0.5)


def test_cancelled_is_void():
    result = settle_selection(Pick("1x2", "home", None, 2.0), fixture(status="CANC"))
    assert result.status == "void"
    assert result.profit_loss == 0


def test_live_remains_pending():
    result = settle_selection(Pick("1x2", "home", None, 2.0), fixture(status="2H"))
    assert result.status == "pending"
